
#!bin/bash

az group delete --resource-group customer0123tfstate -y