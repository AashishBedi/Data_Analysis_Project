TRAINING_BUCKET_NAME = "customer-segmentation-model"
PREDICTION_BUCKET_NAME = "sensor-datasource"
